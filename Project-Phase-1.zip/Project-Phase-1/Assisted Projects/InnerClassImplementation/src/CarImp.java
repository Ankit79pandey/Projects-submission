public class CarImp  implements Car {
	
	public void start() {
		//logic to start
		System.out.println("Car Started");
	}
	
	public void stop() {
		//login for stop
		System.out.println("car Stopped");
	}
	

}