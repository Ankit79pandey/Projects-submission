
public interface Car {
	
	public void start();
	public void stop();

}